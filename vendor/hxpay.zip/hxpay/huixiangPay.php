<?php
//汇享快捷支付
class PayAction
{

    //机构号
    private $appId = 'f6c61712b6854cfd903a63daf65371cd';
    private $privateKey = __DIR__."/cert/huixiang/client.pfx";

    private $privateKeyPass = "123456";
    private $publicKey = __DIR__."/cert/huixiang/server.cer";

    //商户入网地址
    private $url = 'http://api.mypays.cn/api/service.json';

    //回调地址
    private $notify_url = 'http://sbt.ifc007.com/index.php/api/callback';
    //跳转地址
    private $return_url = 'http://sbt.ifc007.com/index.php/api/callback';



    public function index()
    {
        header("Content-type:text/html;charset=utf-8");
        $data = $this->getPublicParams(date('YmdHis'));

        //接口类型 必填
        $postarr['method'] = 'register';
        //商户号  必填
        $postarr['merchant_code'] = time();
        //商户名称     必填
        $postarr['merchant_name'] = 'HXTC0001';
        //商户所在省份  必填
        $postarr['merchant_province'] = '福建省';
        //商户所在城市 必填
        $postarr['merchant_city'] = '福州市';
        //商户所在详细地址 必填
        $postarr['merchant_address'] = '乌山荣域A2座602室';
        //姓名  必填
        $postarr['family_name'] = '张良钦';
        //证件号 必填
        $postarr['id_card'] = '352228199604260517';
        //手机号 必填
        $postarr['mobile'] = '18649738701';
        //结算账号 必填
        $postarr['payee_bank_no'] = '6217906400003137172';
        //总行名称 必填
        $postarr['payee_bank_name'] = '中国银行';
        //总行联行号 必填
        $postarr['payee_bank_id'] = '104100000004';
        //开户行全称 必填
        $postarr['payee_branch_name'] = '中国银行';
        //开户行联行号 必填
        $postarr['payee_branch_code'] = '104100000004';
        //开户行省份 必填
        $postarr['payee_bank_province'] = '福建省';
        //开户行城市
        $postarr['payee_bank_city'] = '福州市';
        //操作标识
        $postarr['merchant_oper_flag'] = 'A';
        //单笔消费交易手续费
        $postarr['counter_fee_t0'] = '200';
        //消费交易手续费扣率 必填
        $postarr['rate_t0'] = '0.50';

        $data['data'] = json_encode($postarr);
        //签名信息 必填
        $data['sign'] = $this->getRsaSign($data,$this->privateKey,$this->privateKeyPass);

        dump($data);
        dump($postarr);
        $url = $this->url;
        $headers[] = 'Content-Type:application/json';
        $rs = $this->http($url,json_encode($data),'POST',$headers);
        $rs = json_decode($rs,true);
        dump($rs);

    }

    //订单支付
    function hxpay($input){

        $down_data = json_decode($input['down_data'],true);
        $data = $this->getPublicParams($input['order_sn']);
        //接口类型 必填
        $postarr['method'] = 'pay';
        //终端商户号 必填
        $postarr['third_merchant_code'] = 'HXTCSHORTCUTPAY@A0001506046699';
        //订单时间  必填
        $postarr['trans_time'] = date("YmdHis");
        //订单日期  必填
        $postarr['trans_date'] = date("Ymd");
        //订单金额 必填
        $postarr['trans_amount'] = '1000';
        //姓名 必填
        $postarr['family_name'] = '张良钦';
        //身份证号 必填
        $postarr['id_card'] = '352228199604260517';
        //卡号 必填
        $postarr['pay_bank_no'] = '6225768769374974';
        //手机号
        $postarr['mobile'] = '18649738701';
        //结算账号 必填
        $postarr['payee_bank_no'] = '6217906400003137172';
        //总行名称 必填
        $postarr['payee_bank_name'] = '中国银行';

        //总行联行号 必填
        $postarr['payee_bank_id'] = '104100000004';
        //到账金额 必填
        $postarr['pay_amount'] = '299';
        //手续费 必填
        $postarr['operation_fee'] = '200';
        //单笔消费交易手续费 必填
        $postarr['counter_fee_t0'] = '1';
        //费率 必填
        $postarr['rate_t0'] = '0.5';
        //备注
        $postarr['memo'] = '';
        //前台通知地址URL
        $postarr['front_notify_url'] = 'xx';
        //后台通知地址URL
        $postarr['back_notify_url'] = 'xx';
        $data['data'] = json_encode($postarr);
        //签名信息 必填
        $data['sign'] = $this->getRsaSign($data,$this->privateKey,$this->privateKeyPass);


        $url = $this->url;
        $headers[] = 'Content-Type:application/json';
        $rs = http($url,json_encode($data),'POST',$headers);
        $rs = json_decode($rs,true);

        return $rs;
    }


    //生成签名
    public function getRsaSign($data, $pfxContent, $privkeypass)
    {
        $pfxContent = file_get_contents($pfxContent);
        $signString	= $this->verifyString($data);
        $pfxContent	= base64_decode($pfxContent);

        openssl_pkcs12_read($pfxContent, $certs, $privkeypass);
        openssl_sign($signString, $signMsg, $certs['pkey'], OPENSSL_ALGO_MD5);	//注册生成加密信息 OPENSSL_ALGO_SHA1
        $signMsg	= base64_encode($signMsg); 								//base64转码加密信息

        return $signMsg;
    }

    //验签
    function checkRsaSign($data, $public_key, $signMsg)
    {
        $public_key = file_get_contents($public_key);
        $signString	= $this->verifyString_notify($data);
        /*$unsignMsg	= base64_decode($signMsg);							//base64解码加密信息
        $cer		= openssl_x509_read($cerContent); 					//读取公钥
        $res		= openssl_verify($signString, $unsignMsg, $cer); 	//验证*/

        $public_key	= str_replace("-----BEGIN CERTIFICATE-----", "", $public_key);
        $public_key	= str_replace("-----END CERTIFICATE-----", "", $public_key);
        $public_key	= str_replace("\n", "", $public_key);
        $public_key	= '-----BEGIN CERTIFICATE-----'.PHP_EOL.wordwrap($public_key, 64, "\n", true) .PHP_EOL.'-----END CERTIFICATE-----';

        $res = openssl_get_publickey($public_key);
        if($res){
            $result = (bool)openssl_verify($signString,base64_decode($signMsg),$res,OPENSSL_ALGO_MD5);
        }else{
            return false;
        }
        openssl_free_key($res);

        return $result;
    }

    //请求签名串组装
    function verifyString($data)
    {
        ksort($data);
        unset($data['sign']);

        $arr	= array();
        foreach($data AS $k => $v){
            if($k != 'sign'){
                $arr[]	= $k."=".$v;
            }
        }

        return implode("&", $arr);
    }

    //回调签名串组装
    function verifyString_notify($data)
    {
        ksort($data);
        unset($data['sign']);

        $arr	= array();
        foreach($data AS $k => $v){
            if($k != 'sign' && $k != 'resp_msg'){
                $arr[]	= $k."=".$v;
            }
        }

        return implode("|", $arr);
    }





    function query(){

        //机构号 必填
        $postarr['app_id'] = $this->appId;
        //机构商户编号  必填
        $postarr['trans_type'] = 'SHORTCUTPAY';
        //瀚银商户号  必填
        $postarr['client_trans_id'] = date('YmdHisS');
        //订单号 必填
        $postarr['trans_timestamp'] = time();
        //订单时间 必填

        //瀚银流水号
        $data['method'] = 'pay_qry';
        //产品类型 必填
        $data['orig_tran_id'] = 'xx';

        $postarr['data'] = json_encode($data);

        //签名信息 必填
        $postarr['sign'] = $this->getRsaSign($postarr,$this->privateKey,'123456');
//        $postarr['sign'] = $this->dfsign($postarr,$this->privateKey,'123456');
        dump($postarr);
        $url = $this->url;
        $headers[] = 'Content-Type:application/json';
        $rs = http($url,json_encode($postarr),'POST',$headers);

        $rs = json_decode($rs,true);
        dump($rs);
    }

    //获取公告参数
    private function getPublicParams($order_sn,$transtype='SHORTCUTPAY'){
        //应用code 必填
        $data['app_id'] = $this->appId;
        //交易类型  必填
        $data['trans_type'] = $transtype;
        //交易流水号  必填
        $data['client_trans_id'] = $order_sn;
        //请求时间 必填
        $data['trans_timestamp'] = time();
        return $data;
    }

    public function notify(){

        //获取回调参数
        $inputxml = file_get_contents("php://input"); //接收POST数据
        $rs = json_decode($inputxml,true);

        $sn = $rs['client_trans_id'];
        if ($rs['resp_code'] == 'PAY_SUCCESS') {


            $sign = $this->checkRsaSign($rs,$this->publicKey,$rs['sign']);
            if(!$sign){

                exit;
            }


        }
    }

    function http($url, $params, $method = 'GET', $header = array(), $timeout = 40){
        $opts = array(
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER     => $header
        );
        /* 根据请求类型设置特定参数 */
        switch(strtoupper($method)){
            case 'GET':
                $opts[CURLOPT_URL] = $url . '?' . http_build_query($params);
                break;
            case 'POST':
                //判断是否传输文件
                $opts[CURLOPT_URL] = $url;
                $opts[CURLOPT_POST] = 1;
                $opts[CURLOPT_POSTFIELDS] = $params;
                break;
            default:
                throw new Exception('不支持的请求方式！');
        }
        /* 初始化并执行curl请求 */
        $ch = curl_init();
        curl_setopt_array($ch, $opts);
        $data  = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        if($error) throw new Exception('请求发生错误：' . $error);
        return  $data;
    }

}